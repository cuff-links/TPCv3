@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.cdyne.com/WeatherWS/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package WeatherClient;
