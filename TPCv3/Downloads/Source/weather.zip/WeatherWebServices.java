/**********************************************
 Developer: Silne Dorlus
 Purpose: To allow the user to look up the
 weather forecast for the next 7 days by
 supplying the zip code.
***********************************************/
import WeatherClient.*;
import javax.swing.*;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class WeatherWebServices extends JFrame
{
    //Instantiate all GUI componenets and class variables.
    JLabel lblEnterZip = new JLabel("Enter Zip Code:");
    JLabel lblWeatherDescription = new JLabel();
    JLabel lblRainHi = new JLabel();
    JLabel lblRainLow = new JLabel();
    JLabel lblDate = new JLabel();
    JLabel lblHiC = new JLabel();
    JLabel lblLowC = new JLabel();
    JLabel lblHiF = new JLabel();
    JLabel lblLowF = new JLabel();
    JTextField txtZip = new JTextField(10);
    JButton btnGetForecast = new JButton("Get Forecast");
    JButton btnExit = new JButton("Exit");
    JLabel lblForecastSummary = new JLabel();
    JPanel panelNorth = new JPanel();
    JPanel panelNorthTop = new JPanel();
    JPanel panelNorthBottom = new JPanel();
    JPanel panelCenter = new JPanel();
    JPanel panelSouth =  new JPanel();
    JPanel panelSouthLeft = new JPanel();
    JPanel panelSouthRight = new JPanel();
    JScrollPane scrollPane;
    DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("Daily Forecasts");
    JTree weatherTree = new JTree(rootNode);
    ArrayOfForecast details;

    public WeatherWebServices()
    {
        //Set layout for JFrame.
        setLayout(new BorderLayout());
        add(panelNorth, BorderLayout.NORTH);

        //Set layout of panel North to Gridlayout and add both panels.
        panelNorth.setLayout(new GridLayout(2, 1));
        panelNorth.add(panelNorthTop);
        panelNorth.add(panelNorthBottom);

        //Set panelNorthTop layout to flowlayout and add components
        panelNorthTop.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelNorthTop.add(lblEnterZip);
        panelNorthTop.add(txtZip);
        panelNorthTop.add(btnGetForecast);
        panelNorthTop.add(btnExit);

        //Set layout of panelNorthBottom to Flowlayout and add label.
        panelNorthBottom.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelNorthBottom.add(lblForecastSummary);

        //Set layout of panelCenter to flowLayout left, set background color, create border,
        //add tree, add panel to scrollpane and add scrollpane to Jframe.
        panelCenter.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelCenter.setBorder(BorderFactory.createLoweredSoftBevelBorder());
        panelCenter.setBackground(Color.white);
        panelCenter.add(weatherTree);
        scrollPane = new JScrollPane(panelCenter);
        add(scrollPane, BorderLayout.CENTER);

        //Set panelSouth layout and add all components.
        panelSouth.setLayout(new GridLayout(1, 2));
        add(panelSouth, BorderLayout.SOUTH);
        panelSouthLeft.setLayout(new GridLayout(3, 1));
        panelSouthRight.setLayout(new GridLayout(5,1));
        panelSouthLeft.add(lblWeatherDescription);
        panelSouthLeft.add(lblRainHi);
        panelSouthLeft.add(lblRainLow);
        panelSouthRight.add(lblDate);
        panelSouthRight.add(lblHiF);
        panelSouthRight.add(lblLowF);
        panelSouthRight.add(lblHiC);
        panelSouthRight.add(lblLowC);
        panelSouth.add(panelSouthLeft);
        panelSouth.add(panelSouthRight);

        //Add action listeners to buttons and set up treelisteners.
        ActionListener weatherListener = new WeatherListener();
        btnExit.addActionListener(weatherListener);
        btnGetForecast.addActionListener(weatherListener);
        SetupTreeListeners();
    }
    public static void main(String[] args)
    {
        WeatherWebServices objWeather = new WeatherWebServices();
        objWeather.setTitle("Weather Forecast");
        objWeather.setSize(400, 550);
        objWeather.setResizable(false);
        objWeather.setVisible(true);
        objWeather.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    public void SetupTreeListeners()
    {
            //Create selection listener for tree and override. Load the selected node.
          weatherTree.addTreeSelectionListener(
                  new TreeSelectionListener() {
                      @Override
                      public void valueChanged(TreeSelectionEvent event)
                      {
                          try
                          {
                              LoadSelectedNode(event.getPath().toString());
                          }
                          catch (Exception ex)
                          {
                              JOptionPane.showMessageDialog(null, "Cannot expand selected node.",
                                      "Node Expansion Error" , JOptionPane.ERROR_MESSAGE);
                          }

                      }
                  }
          );
          //Add expansionlistener and override. Load the selected node.
          weatherTree.addTreeExpansionListener(
                  new TreeExpansionListener() {
                      @Override
                      public void treeExpanded(TreeExpansionEvent event) {
                          LoadSelectedNode(event.getPath().toString());
                      }

                      @Override
                      public void treeCollapsed(TreeExpansionEvent event) {}
                  }
          );
    }
    public void LoadSelectedNode(String selectedNode)
    {
        //Check which node from the ArrayofForecasts is selected and load data
        //by checking the path.
        for (int i= 0; i < details.getForecast().size() ; i++)
        {
            Forecast forecast = details.getForecast().get(i);
            String date = DateTransform(forecast.getDate().toGregorianCalendar());
            if (selectedNode.equals("[Daily Forecasts, " + date + "]"))
            {
                lblDate.setText(date);
                lblHiF.setText(BuildWeatherString(
                        forecast.getTemperatures().getDaytimeHigh(), true, true));
                lblLowF.setText(BuildWeatherString(
                        forecast.getTemperatures().getMorningLow(), false, true));
                lblHiC.setText(BuildWeatherString(
                        forecast.getTemperatures().getDaytimeHigh(), true, false));
                lblLowC.setText(BuildWeatherString(
                        forecast.getTemperatures().getMorningLow(), false, false));
                lblWeatherDescription.setText(forecast.getDesciption());
                lblRainHi.setText(BuildWeatherString(
                        forecast.getProbabilityOfPrecipiation().getDaytime(), true ));
                lblRainLow.setText(BuildWeatherString(
                        forecast.getProbabilityOfPrecipiation().getNighttime(), false ));
            }
        }
    }
    public String DateTransform(GregorianCalendar calendar)
    {
        //Change date to day, Month dd, yyyy
        StringBuilder dateString = new StringBuilder();
        dateString.append(DayString(calendar.get(Calendar.DAY_OF_WEEK)) + ", ");
        dateString.append(MonthString(calendar.get(Calendar.MONTH)+1) + " ");
        dateString.append(calendar.get(Calendar.DAY_OF_MONTH) + ", ");
        dateString.append(calendar.get(Calendar.YEAR));
        return dateString.toString();
    }
    public class WeatherListener implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
             if (event.getSource() ==  btnExit)
             {
                 int decision = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit?",
                         JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                 if (decision == JOptionPane.YES_OPTION)
                 {
                     System.exit(1);
                 }
             }
            else if (event.getSource() == btnGetForecast)
             {
                 //Always clear all nodes when forecast is being retrieved.
                 ClearAllNodes();

                 String enteredZip = txtZip.getText();
                 if (ValidateZipCode(enteredZip))
                 {
                     Weather webservice = new Weather();
                     WeatherSoap client =  webservice.getWeatherSoap();
                     ForecastReturn service = client.getCityForecastByZIP(enteredZip);

                     //Check is forecast is null
                     if (service != null)
                     {
                         details = service.getForecastResult();
                         //Check if service successfully returned result
                         if (service.isSuccess())
                         {
                             //If more than 7  resuls returned, set size to 7
                             int size  = details.getForecast().size();
                             if (size > 7){ size=7; }

                             //Set text of summary to location and weather station location.
                             if (size > 0)
                             {
                                 lblForecastSummary.setText("Location: " + service.getCity() + ", " + service.getState() +
                                  "          Weather Station: " + service.getWeatherStationCity() + ", " +
                                         service.getState());

                                 //Iterate through list of forecasts and create nodes if the data is not empty.
                                 //Add nodes to rootNode.
                                 List<Forecast> forecastList = details.getForecast();
                                 for (Forecast currentDay: forecastList)
                                 {
                                     GregorianCalendar calendar = currentDay.getDate().toGregorianCalendar();
                                     DefaultMutableTreeNode day = new DefaultMutableTreeNode(DateTransform(calendar));
                                     DefaultMutableTreeNode[] dayWeather = new DefaultMutableTreeNode[6];
                                     if (!currentDay.getTemperatures().getDaytimeHigh().trim().isEmpty())
                                     {
                                         dayWeather[0] = new DefaultMutableTreeNode(BuildWeatherString(
                                                 currentDay.getTemperatures().getDaytimeHigh(), true, true));
                                     }
                                     if (!currentDay.getTemperatures().getMorningLow().trim().isEmpty())
                                     {
                                         dayWeather[1] = new DefaultMutableTreeNode(
                                         BuildWeatherString(currentDay.getTemperatures().getMorningLow(), false, true));
                                     }
                                     if (!currentDay.getTemperatures().getDaytimeHigh().trim().isEmpty())
                                     {
                                         dayWeather[2] = new DefaultMutableTreeNode(BuildWeatherString(
                                                 currentDay.getTemperatures().getDaytimeHigh(), true, false));
                                     }
                                     if (!currentDay.getTemperatures().getMorningLow().trim().isEmpty())
                                     {
                                         dayWeather[3] = new DefaultMutableTreeNode(BuildWeatherString(
                                                 currentDay.getTemperatures().getMorningLow(), false, false));
                                     }
                                     if (!currentDay.getProbabilityOfPrecipiation().getDaytime().isEmpty())
                                     {
                                          dayWeather[4] = new DefaultMutableTreeNode(BuildWeatherString(
                                             currentDay.getProbabilityOfPrecipiation().getDaytime(), true ));
                                     }
                                     if (!currentDay.getProbabilityOfPrecipiation().getNighttime().isEmpty())
                                     {
                                         dayWeather[5] = new DefaultMutableTreeNode(BuildWeatherString(
                                                 currentDay.getProbabilityOfPrecipiation().getNighttime(), false ));
                                     }
                                     rootNode.add(day);
                                     for (DefaultMutableTreeNode temp:dayWeather)
                                     {
                                         if (temp != null)
                                         {
                                             day.add(temp);
                                         }

                                     }
                                 }
                             }
                             weatherTree.expandPath(new TreePath(rootNode));
                         }
                         else
                         {
                             lblForecastSummary.setText("No results returned for supplied zip code.");
                         }
                     }
                 }
                 else
                 {
                     JOptionPane.showMessageDialog(null, "Please enter a valid 5 digit zip code.", "Invalid Zip Error"
                             , JOptionPane.ERROR_MESSAGE);
                 }
             }
        }
    }
    public void ClearAllNodes()
    {
        //Clear all nodes and then reload tree.
        rootNode.removeAllChildren();
        ((DefaultTreeModel)weatherTree.getModel()).reload(rootNode);

    }
    public boolean ValidateZipCode(String zipCode)
    {
        //Check if string length is 5 and then check if it can be parsed to int. If not, invalid.
        if (zipCode.length() == 5)
        {
            try
            {
                Integer.parseInt(zipCode);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        else
        {
            return false;
        }
    }
    public String GetDegreesCelsius(String degrees)
    {
        //try to perform math operation to calculate celsius.
        try
        {
            int fDegrees = Integer.parseInt(degrees);
            double cDegrees =  (double)(fDegrees - 32) * (double)(5.0/9.0);
            return String.valueOf((int)cDegrees);
        }
        catch (Exception ex)
        {
            return "";
        }

    }
    public String BuildWeatherString(String temp, boolean isHigh, boolean isFahrenheit)
    {
        StringBuilder tempString = new StringBuilder();
        //Check is given string is empty, if so return ""
        // if not check if is high, then check if is fahrenheit and build stringbuilder. Then return string.
        if (!temp.isEmpty())
        {
            if (isHigh)
            {
                tempString.append("Hi: ");
                if (isFahrenheit)
                {
                    tempString.append(temp + " degrees F");
                }
                else
                {
                    tempString.append(GetDegreesCelsius(temp) + " degrees C");
                }
            }
            else
            {
                tempString.append("Low: ");
                if (isFahrenheit)
                {
                    tempString.append(temp + " degrees F");
                }
                else
                {
                    tempString.append(GetDegreesCelsius(temp) + " degrees C");
                }
            }
        return tempString.toString();
        }
        else
        {
            return "";
        }
    }
    public String  BuildWeatherString(String rain, boolean isDaytime)
    {
        StringBuilder rainString = new StringBuilder();
        //Check is given string is empty, if so return ""
        // if not check if isDaytime and build stringbuilder. Then return string.
        if (!rain.isEmpty())
        {
            if (isDaytime)
            {
                rainString.append("Daytime precipitation: " + rain + "%");
            }
            else
            {
                rainString.append("Nighttime precipitation: " + rain + "%");
            }
            return rainString.toString();
        }
        else
        {
            return "";
        }
    }
    public String MonthString(int monthNumber)
    {
        //Return string for corresponding month.
         switch (monthNumber)
         {
             case(1):
                return "January";
             case(2):
                return "February";
             case(3):
                 return "March";
             case(4):
                 return "April";
             case(5):
                 return "May";
             case(6):
                 return "June";
             case(7):
                 return "July";
             case(8):
                 return "August";
             case(9):
                 return "September";
             case(10):
                 return "October";
             case(11):
                 return "November";
             case(12):
                 return "December";

         }
        return "Invalid Month";
    }
    public String DayString(int dayNumber)
    {
        //Return string for corresponding day.
        switch (dayNumber)

        {
            case(1):
            return "Sunday";
            case(2):
            return "Monday";
            case(3):
            return "Tuesday";
            case(4):
            return "Wednesday";
            case(5):
            return "Thursday";
            case(6):
            return "Friday";
            case(7):
            return "Saturday";
        }
        return "Invalid day";
    }
}
