

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

/**
 * Developer: Silne Dorlus
 * Date: 5/7/12
 * Time: 8:14 PM
 */
public class Elimination extends JFrame implements ActionListener
{
    int roll1, roll2, sum;
    int lowScore = 78;
    int currentScore = 78;
    boolean isDoubles = false;
    boolean sumClicked = false;
    JButton btn1 = new JButton("1");
    JButton btn2 = new JButton("2");
    JButton btn3 = new JButton("3");
    JButton btn4 = new JButton("4");
    JButton btn5 = new JButton("5");
    JButton btn6 = new JButton("6");
    JButton btn7 = new JButton("7");
    JButton btn8 = new JButton("8");
    JButton btn9 = new JButton("9");
    JButton btn10 = new JButton("10");
    JButton btn11 = new JButton("11");
    JButton btn12 = new JButton("12");
    //add all of the bottom buttons to an array
    JButton[] buttonArray = {btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12};
    JButton btnReset = new JButton("Reset");
    JButton btnRoll = new JButton("Roll");
    JButton btnRules = new JButton("Rules");
    JPanel panelLowScore  = new JPanel();
    JPanel panelCurrentScore = new JPanel();
    JPanel panelBottomButtons = new JPanel();
    JPanel panelCenter = new JPanel();
    JPanel panelCenterTop = new JPanel();
    JPanel panelCenterMiddle = new JPanel();
    JPanel panelCenterBottom = new JPanel();
    JRadioButton radioBlue= new JRadioButton();
    JRadioButton radioRed= new JRadioButton();
    JRadioButton radioGreen= new JRadioButton();
    JLabel lblCurrentScoreHeader = new JLabel("Current Score");
    JLabel lblCurrentScore = new JLabel(String.valueOf(currentScore));
    JLabel lblLowScoreHeader = new JLabel("Lowest Score");
    JLabel lblLowScore = new JLabel(String.valueOf(lowScore));
    JLabel lblFirstRoll = new JLabel("6");
    JLabel lblSecondRoll = new JLabel("6");
    Dice dice1 = new Dice();
    Dice dice2 = new Dice();
    boolean firstRoll = true;
    boolean clickingRolls = false;
    boolean totalClicked = false;
    int sumTotal =0;


    public Elimination()
    {
        btn1.setMnemonic(KeyEvent.VK_1);
        btn2.setMnemonic(KeyEvent.VK_2);
        btn3.setMnemonic(KeyEvent.VK_3);
        btn4.setMnemonic(KeyEvent.VK_4);
        btn5.setMnemonic(KeyEvent.VK_5);
        btn6.setMnemonic(KeyEvent.VK_6);
        btn7.setMnemonic(KeyEvent.VK_7);
        btn8.setMnemonic(KeyEvent.VK_8);
        btn9.setMnemonic(KeyEvent.VK_9);
        btn10.setMnemonic(KeyEvent.VK_0);
        btn11.setMnemonic(KeyEvent.VK_A);
        btn12.setMnemonic(KeyEvent.VK_B);
        btnReset.setMnemonic(KeyEvent.VK_C);
        btnRoll.setMnemonic(KeyEvent.VK_R);
        btnRules.setMnemonic(KeyEvent.VK_P);

        setLayout(new BorderLayout());
        //Add panel for buttons on the bottom to the JFrame and then add the buttons to that panel. Also disable the buttons.
        panelBottomButtons.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        add(panelBottomButtons, BorderLayout.SOUTH);
        panelBottomButtons.setLayout(new GridLayout(1,1));
        for (int i = 0 ; i < buttonArray.length ; i++)
        {

            buttonArray[i].addActionListener(this);
            buttonArray[i].setEnabled(false);
            buttonArray[i].setToolTipText("Press this to use the eliminate the number " + (i + 1) + ".");
            panelBottomButtons.add(buttonArray[i]);
        }
        //Add Panel for  Current score to the JFrame then add the labels to that panel.
        panelCurrentScore.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        add(panelCurrentScore, BorderLayout.WEST);
        lblCurrentScore.setFont(new Font("Arial", Font.BOLD, 48));
        panelCurrentScore.setLayout(new GridLayout(2,1));
        lblCurrentScoreHeader.setFont( new Font("Arial" , Font.BOLD, 24));
        panelCurrentScore.add(lblCurrentScoreHeader);
        panelCurrentScore.add(lblCurrentScore);

        //Add panel for Lowest Score to JFrame and then add labels to that panel.
        panelLowScore.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        add(panelLowScore, BorderLayout.EAST);
        lblLowScoreHeader.setFont( new Font("Arial" , Font.BOLD, 24));
        lblLowScore.setFont(new Font("Arial", Font.BOLD, 48));
        panelLowScore.setLayout(new GridLayout(2,1));
        panelLowScore.add(lblLowScoreHeader);
        panelLowScore.add(lblLowScore);

        //Add panel for the Center Controls set it's layout to Borderlayout.
        panelCenter.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        add(panelCenter, BorderLayout.CENTER);
        panelCenter.setLayout(new BorderLayout());


        //Add 3 regions to panelCenter to organize the interface.
        panelCenter.add(panelCenterTop, BorderLayout.NORTH);
        panelCenterTop.setBorder(BorderFactory.createTitledBorder("Set Background Color"));
        panelCenter.add(panelCenterMiddle, BorderLayout.CENTER);
        panelCenter.add(panelCenterBottom, BorderLayout.SOUTH);

        //Add radiobuttons to panelCenterTop panel. Place them in a group.
        ButtonGroup group = new ButtonGroup();
        group.add(radioBlue);
        group.add(radioRed);
        group.add(radioGreen);
        radioBlue.setText("Blue");
        radioRed.setText("Red");
        radioGreen.setText("Green");
        panelCenterTop.add(radioRed);
        radioRed.addActionListener(this);
        panelCenterTop.add(radioGreen);
        radioGreen.addActionListener(this);
        panelCenterTop.add(radioBlue);
        radioBlue.addActionListener(this);

        //Add labels for scores to panelCenterMiddle panel.
        lblFirstRoll.setFont(new Font("Arial", Font.BOLD, 48));
        lblSecondRoll.setFont(new Font("Arial", Font.BOLD, 48));
        panelCenterMiddle.add(lblFirstRoll);
        panelCenterMiddle.add(lblSecondRoll);

        //Add buttons to The panelCenterBottom panel.
        panelCenterBottom.add(btnRoll);
        btnRoll.addActionListener(this);
        btnRoll.setToolTipText("Click to roll dice.");
        panelCenterBottom.add(btnReset);
        btnReset.addActionListener(this);
        btnReset.setToolTipText("Click to start new game and check for low score.");
        panelCenterBottom.add(btnRules);
        btnRules.addActionListener(this);
        btnRules.setToolTipText("Click for gameplay rules.");


    }
    public static void main(String[] args)
    {
        Elimination elimination = new Elimination();
        elimination.setSize(597, 250);
        elimination.setTitle("Elimination");
        elimination.setVisible(true);
    }
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == btnRoll)
        {
            btnRoll.setEnabled(false);
            if (firstRoll == true)
            {
                for (int i = 0; i < buttonArray.length; i++)
                {
                    if (buttonArray[i].isEnabled() == false)
                    {
                        buttonArray[i].setEnabled(true);
                    }
                }
            }
            isDoubles = false;
            clickingRolls =false;
            sumClicked = false;
            roll1 = dice1.rollDice();
            roll2 = dice2.rollDice();
            sum = roll1 + roll2;
            lblFirstRoll.setText(String.valueOf(roll1));
            lblSecondRoll.setText(String.valueOf(roll2));
            if (roll1 == roll2)
            {
                isDoubles = true;
            }
        }
        else
        if (e.getSource() == btn1 || e.getSource() == btn2 || e.getSource() == btn3 || e.getSource() == btn4 || e.getSource() == btn5 ||
                e.getSource() == btn5 || e.getSource() == btn6 || e.getSource() == btn7 || e.getSource() == btn8 || e.getSource() == btn9 ||
                e.getSource() == btn10 || e.getSource() == btn11 || e.getSource() == btn12)
        {

              if (isDoubles == true)
              {
                  if ( Integer.parseInt(((JButton) e.getSource()).getText()) == sum )
                  {
                         totalClicked = true;
                         CheckClick(e, sum);
                  }
                  else
                  {
                      JOptionPane.showMessageDialog(null, "Please click the number " + sum, "Error: Wrong Number",JOptionPane.ERROR_MESSAGE );
                  }
              }
              else
              {
                  if (sumClicked == false)
                  {
                      if ( Integer.parseInt(((JButton) e.getSource()).getText()) == sum && clickingRolls == false)
                      {
                          CheckClick(e, sum);
                          sumClicked = true;
                          btnRoll.setEnabled(true);
                      }
                      else
                      if (Integer.parseInt(((JButton) e.getSource()).getText()) == roll1 || Integer.parseInt(((JButton) e.getSource()).getText()) == roll2)
                      {
                          if( sumTotal != sum)
                          {
                              totalClicked = false;
                              sumTotal += Integer.parseInt(((JButton) e.getSource()).getText());
                              if (sumTotal == sum)           
                              {
                                  totalClicked = true;
                              }
                          }
                          else
                          {
                              totalClicked = true;
                          }
                          clickingRolls = true;
                          CheckClick(e, Integer.parseInt((((JButton) e.getSource()).getText())));
                      }
                      else
                      {
                          JOptionPane.showMessageDialog(null, "Please eliminate either " + roll1 + " and " + roll2 + " or " + sum,
                                  "Error: Wrong Number",JOptionPane.ERROR_MESSAGE );
                      }
                  }
                  else
                  {
                      JOptionPane.showMessageDialog(null, "Please roll again or reset if you cannot eliminate." , "Error: No More Clicks",JOptionPane.ERROR_MESSAGE );
                  }
              }
        }
        else
        if (e.getSource() == btnReset)
        {
            int resetGame = JOptionPane.showConfirmDialog(null, "Are you sure you want to restart?", "Restart Game?", 
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
             if (resetGame ==  JOptionPane.YES_OPTION)
             {
                for (int i = 0 ; i < buttonArray.length ; i++)
                {
                    buttonArray[i].setEnabled(false);
                }
                if (currentScore < lowScore)
                {
                    lowScore = currentScore;
                    lblLowScore.setText(String.valueOf(lowScore));

                }
                sumTotal = 0;
                btnRoll.setEnabled(true);
                firstRoll = true;
                currentScore = 78;
                lblCurrentScore.setText(String.valueOf(currentScore));
             }
        }
        else
        if  (e.getSource() == btnRules)
        {
            JOptionPane.showMessageDialog(null, "The object of the game is to eliminate as many number as possible to achieve" + System.getProperty("line.separator") +
                    "the lowest possible score. Press Roll to roll the dice. When you get your dice values you must either" +  System.getProperty("line.separator") +
                    "click on the two values of the dice or the sum of the two. Once you can't click on a button, the game is over." +  System.getProperty("line.separator") +
                    "Hot keys are Alt + the number for 1-9. Alt + 0 for 10. Alt + a for 11. Alt + b for 12. Alt + R to Roll. Alt + C to reset. Alt + P for rules."
                    , "Elimination: Rules",JOptionPane.INFORMATION_MESSAGE );
        }
        else
        if (e.getSource() == radioBlue)
        {
            panelCenterTop.setBackground(Color.cyan);
            panelCenterMiddle.setBackground(Color.cyan);
            panelCenterBottom.setBackground(Color.cyan);
            panelLowScore.setBackground(Color.cyan);
            panelCurrentScore.setBackground(Color.cyan);
            radioBlue.setBackground(Color.cyan);
            radioRed.setBackground(Color.cyan);
            radioGreen.setBackground(Color.cyan);
        }
        if (e.getSource() == radioRed)
        {
            panelCenterTop.setBackground(Color.red);
            panelCenterMiddle.setBackground(Color.red);
            panelCenterBottom.setBackground(Color.red);
            panelLowScore.setBackground(Color.red);
            panelCurrentScore.setBackground(Color.red);
            radioBlue.setBackground(Color.red);
            radioRed.setBackground(Color.red);
            radioGreen.setBackground(Color.red);
        }
        if (e.getSource() == radioGreen)
        {
            panelCenterTop.setBackground(Color.green);
            panelCenterMiddle.setBackground(Color.green);
            panelCenterBottom.setBackground(Color.green);
            panelLowScore.setBackground(Color.green);
            panelCurrentScore.setBackground(Color.green);
            radioBlue.setBackground(Color.green);
            radioRed.setBackground(Color.green);
            radioGreen.setBackground(Color.green);
        }
    }
    public void CheckClick(ActionEvent event, int rollNum)
    {

        currentScore -= rollNum;
        lblCurrentScore.setText(String.valueOf(currentScore));
        ((JButton) event.getSource()).setEnabled(false);
        firstRoll = false;
        if (totalClicked == true)
        {
            btnRoll.setEnabled(true);
            sumTotal = 0;
        }

    }
}
