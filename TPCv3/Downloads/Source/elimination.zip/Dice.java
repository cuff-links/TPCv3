import sun.org.mozilla.javascript.internal.ast.WhileLoop;

import java.util.Random;

/****************************************************************
 * Developer: Silne Dorlus
 * Date: 5/8/12
 * Time: 12:02 AM
 This class is used to generate the dice numbers using a random generator class.
 Also makes sure the number generated is greater than 0 but less than 7.
 ****************************************************************/
public class Dice
{
    private int roll;

    public void setRoll(int argRoll)
    {
        if (argRoll <= 6 && argRoll >= 1)
        {
            roll = argRoll;
        }
    }
    public int getRoll()
    {
        return roll;
    }
    public int rollDice()
    {
        Random random =  new Random();
        int diceRoll = 0;
        do
        {
            diceRoll = random.nextInt(7);
        }
        while( diceRoll < 1);
        setRoll(diceRoll);
        return getRoll();

    }
}
