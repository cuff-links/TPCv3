import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/********************************************
 * Developer: Silne Dorlus
 * Date: 5/19/12
 * Time: 5:14 PM
 ********************************************/
public class Image
{
    private  File soundFile;
    private BufferedImage imageFile;
    private AudioFormat audioFormat;
    private AudioInputStream audioStream;
    private SourceDataLine sourceLine;
    private String soundString;
    private final int BUFFER_SIZE = 128000;
    private int width, height;

    Image(String imagePath)
    {
        set_imageIcon(imagePath);
        setSoundFile(null);
    }
    Image(String imagePath, String audioPath )
    {
        set_imageIcon(imagePath);
        setSoundFile(audioPath);
    }
    public BufferedImage getImageFile()
    {
         return imageFile ;
    }
    public void set_imageIcon(String imageString)
    {
            try
            {
                imageFile = ImageIO.read( new File(System.getProperty("user.dir") + imageString));
                width = imageFile.getWidth();
                height = imageFile.getHeight();

            }
            catch (IOException ex)
            {
                ex.printStackTrace();
            }

    }
    public void setSoundFile(String audioString)
    {
        soundString = audioString;
    }
    public void PlaySound()
    {
        try
        {    if (soundString != null)
            {
                soundFile = new File(System.getProperty("user.dir") + soundString);
            }
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(null, "Error loading audio file. Image may not have audio file.", "Audio File Error", JOptionPane.ERROR_MESSAGE);
        }
        try
        {
              audioStream = AudioSystem.getAudioInputStream(soundFile);
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(null, "Error loading audio file. Image may not have audio file.", "Audio File Error", JOptionPane.ERROR_MESSAGE);
        }
        audioFormat = audioStream.getFormat();

        DataLine.Info info = new DataLine.Info(SourceDataLine.class, audioFormat);
        try
        {
            sourceLine = (SourceDataLine)AudioSystem.getLine(info);
            sourceLine.open(audioFormat);
        }
        catch (LineUnavailableException ex)
        {
            ex.printStackTrace();
            System.exit(1);
        }

        sourceLine.start();

        int nBytesRead = 0;
        byte[] abData = new byte[BUFFER_SIZE];
        while (nBytesRead != -1) {
            try {
                nBytesRead = audioStream.read(abData, 0, abData.length);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (nBytesRead >= 0) {
                @SuppressWarnings("unused")
                int nBytesWritten = sourceLine.write(abData, 0, nBytesRead);
            }
        }

        sourceLine.drain();
        sourceLine.close();
    }
}
