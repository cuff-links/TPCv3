import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.event.KeyEvent;

/********************************************
 * Developer: Silne Dorlus
 * Date: 5/19/12
 * Time: 5:14 PM
 ********************************************/
public class ImageAlbum extends JFrame
{


    //Create all components that will be in the application with their default values.
    JPanel panelSouth = new JPanel();
    JPanel panelEast = new JPanel();
    JPanel panelWest = new JPanel();
    JPanel panelCenter = new JPanel();
    JMenu fileMenu = new JMenu("File");
    JMenuItem openItem =  new JMenuItem("Open");
    JMenuItem closeItem =  new JMenuItem("Close");
    JMenuItem exitItem =  new JMenuItem("Exit");
    JMenuBar menuBar = new JMenuBar();
    JMenu helpMenu = new JMenu("Help");
    JMenuItem helpItem =  new JMenuItem("Help");
    JMenu viewMenu = new JMenu("View");
    JMenuItem playSoundItem =  new JMenuItem("Play Sound");
    JMenuItem aboutItem = new JMenuItem("About Image Album");
    JMenuItem zoomInItem =  new JMenuItem("Zoom In");
    JMenuItem zoomOutItem =  new JMenuItem("Zoom Out");
    JButton openButton = new JButton("Open");
    JButton closeButton = new JButton("Close");
    JButton zoomInButton = new JButton("Zoom In");
    JButton zoomOutButton = new JButton("Zoom Out");
    JButton firstButton = new JButton("<<");
    JButton previousButton = new JButton("<");
    JButton nextButton = new JButton(">");
    JButton lastButton = new JButton(">>");
    JButton playSoundButton = new JButton("Play Audio");
    Image[] images = {new Image("\\images\\cheetah1.bmp"), new Image("\\images\\elephant1.bmp", "\\audio\\elephant1.wav"),
            new Image("\\images\\golden1.bmp","\\audio\\dog1.wav" ), new Image("\\images\\horse1.bmp"),
            new Image("\\images\\horse2.bmp"),new Image("\\images\\lion1.bmp","\\audio\\lion1.wav"),
            new Image("\\images\\monkey1.bmp","\\audio\\monkey1.wav"), new Image("\\images\\polarbear1.bmp"),
            new Image("\\images\\sheep1.bmp","\\audio\\sheep1.wav"), new Image("\\images\\tiger1.bmp")};
    ActionListener albumListener = new AlbumListener();
    JLabel picLabel = null;
    ImageIcon icon = null;
    int imageCounter = 0;
    int zoomCounter = 0;
    int width, height;
    double scaleX = 1;
    double scaleY = 1;
    boolean albumOpened = true;
    BufferedImage currentImage, resizedImage;
    public ImageAlbum()
    {
        //Add the 4 panels to the BorderLayout
        setLayout( new BorderLayout());

        add(panelSouth, BorderLayout.SOUTH);
        add(panelEast, BorderLayout.EAST);
        add(panelWest, BorderLayout.WEST);
        add(panelCenter, BorderLayout.CENTER);

        //Create the File Menu. Add Open, Close and Exit Options. Add to Menu Bar.
        fileMenu.add(openItem);
        openItem.setEnabled(false);
        fileMenu.add(closeItem);
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);

        //Create the View Menu with the Play sound, separator,  zoom in and zoom out options. Add to menu bar.

        viewMenu.add(playSoundItem);
        viewMenu.add(new JSeparator());
        viewMenu.add(zoomInItem);
        viewMenu.add(zoomOutItem);
        menuBar.add(viewMenu);

        //Create the Help MEnu with the help and about options. Add to menu bar

        helpMenu.add(helpItem);
        helpMenu.add(aboutItem);
        menuBar.add(helpMenu);

        // Set the Menu Bar for the application
        setJMenuBar(menuBar);
        
        
        //Add open and close button to the West side of the Border Layout
        panelWest.add(openButton);
        openButton.setEnabled(false);
        panelWest.add(closeButton);

        //Add zoom in and zoom out button to the east side of the border layout
        panelEast.add(zoomInButton);
        panelEast.add(zoomOutButton);

        //Add actionListeners to all buttons and options
        openButton.addActionListener(albumListener);
        closeButton.addActionListener(albumListener);
        zoomInButton.addActionListener(albumListener);
        zoomOutButton.addActionListener(albumListener);
        firstButton.addActionListener(albumListener);
        previousButton.addActionListener(albumListener);
        nextButton.addActionListener(albumListener);
        lastButton.addActionListener(albumListener);
        playSoundButton.addActionListener(albumListener);
        openItem.addActionListener(albumListener);
        closeItem.addActionListener(albumListener);
        exitItem.addActionListener(albumListener);
        zoomInItem.addActionListener(albumListener);
        zoomOutItem.addActionListener(albumListener);
        playSoundItem.addActionListener(albumListener);
        helpItem.addActionListener(albumListener);
        aboutItem.addActionListener(albumListener);

        //Add buttons to panelSouth
        panelSouth.add(firstButton);
        panelSouth.add(previousButton);
        panelSouth.add(nextButton);
        panelSouth.add(lastButton);
        panelSouth.add(playSoundButton);

        //get the current image and add it to Icon. Add that Icon to a JLabel.
        currentImage =  images[imageCounter].getImageFile();
        icon =  new ImageIcon(currentImage);
        picLabel = new JLabel (icon);
        panelCenter.setLayout(new BorderLayout());
        panelCenter.add(picLabel, BorderLayout.CENTER);

        //Add shortcut keys.
        openButton.setMnemonic(KeyEvent.VK_O);
        closeButton.setMnemonic(KeyEvent.VK_C);
        zoomInButton.setMnemonic(KeyEvent.VK_UP);
        zoomOutButton.setMnemonic(KeyEvent.VK_DOWN);
        nextButton.setMnemonic(KeyEvent.VK_RIGHT);
        previousButton.setMnemonic(KeyEvent.VK_LEFT);
        firstButton.setMnemonic(KeyEvent.VK_HOME);
        lastButton.setMnemonic(KeyEvent.VK_END);
        playSoundButton.setMnemonic(KeyEvent.VK_P);
        helpItem.setMnemonic(KeyEvent.VK_H);
        aboutItem.setMnemonic(KeyEvent.VK_A);
        fileMenu.setMnemonic(KeyEvent.VK_F);
        viewMenu.setMnemonic(KeyEvent.VK_V);
        helpMenu.setMnemonic(KeyEvent.VK_M);
		
		//Add tooltips
        openButton.setToolTipText("Open image album and display pictures.");
        openItem.setToolTipText("Open image album and display pictures.");
        closeButton.setToolTipText("Close image album and hide pictures.");
        closeItem.setToolTipText("Close image album and hide pictures.");
        zoomInButton.setToolTipText("Zoom in on picture.");
        zoomInItem.setToolTipText("Zoom in on picture.");
        zoomOutButton.setToolTipText("Zoom out from picture.");
        zoomOutItem.setToolTipText("Zoom out from picture.");
        previousButton.setToolTipText("Show previous picture.");
        nextButton.setToolTipText("Show next picture.");
        firstButton.setToolTipText("Show first picture.");
        lastButton.setToolTipText("Show last picture.");
        playSoundButton.setToolTipText("Play sound file for image (If it has one.)");
        playSoundItem.setToolTipText("Play sound file for image (If it has one.)");
        helpItem.setToolTipText("Show help menu.");
        aboutItem.setToolTipText("About Image Album");
        exitItem.setToolTipText("Exit Image Album");

    }
    public static void main(String[] args)
    {
		//Initialize ImageAlbum Class 
        ImageAlbum imageAlbum = new ImageAlbum();
        imageAlbum.setTitle("Image Album");
        imageAlbum.setSize(600,400);
        imageAlbum.setVisible(true);
    }
    private class AlbumListener implements ActionListener
    {
		//This AlbumListener class is the class that handles all of the events in the program.
        public void actionPerformed(ActionEvent e)
        {
            if (e.getSource() == openItem || e.getSource() == openButton)
            {
                zoomInButton.setEnabled(true);
                zoomInItem.setEnabled(true);
                zoomOutButton.setEnabled(true);
                zoomOutItem.setEnabled(true);
                previousButton.setEnabled(true);
                lastButton.setEnabled(true);
                nextButton.setEnabled(true);
                firstButton.setEnabled(true);
                playSoundButton.setEnabled(true);
                playSoundItem.setEnabled(true);
                closeButton.setEnabled(true);
                closeItem.setEnabled(true);
                openButton.setEnabled(false);
                openItem.setEnabled(false);
                scaleX = 1;
                scaleY = 1;
                imageCounter = 0;
                zoomCounter = 0;
                currentImage = images[imageCounter].getImageFile();
                RefreshPic(currentImage);
            }
            else
            if (e.getSource() == closeButton || e.getSource() == closeItem)
            {
                zoomCounter = 0;
                picLabel.setVisible(false);
                zoomInButton.setEnabled(false);
                zoomInItem.setEnabled(false);
                zoomOutButton.setEnabled(false);
                zoomOutItem.setEnabled(false);
                previousButton.setEnabled(false);
                lastButton.setEnabled(false);
                nextButton.setEnabled(false);
                firstButton.setEnabled(false);
                playSoundButton.setEnabled(false);
                playSoundItem.setEnabled(false);
                closeButton.setEnabled(false);
                closeItem.setEnabled(false);
                openButton.setEnabled(true);
                openItem.setEnabled(true);
            }
            else
            if (e.getSource() == nextButton )
            {
                if (imageCounter <= 8)
                {
                    previousButton.setEnabled(true);
                    firstButton.setEnabled(true);
                    imageCounter +=1;
                    zoomCounter = 0;
                    scaleX = 1;
                    scaleY = 1;
                    currentImage = images[imageCounter].getImageFile();
                    RefreshPic(currentImage);
                }
                else
                {
                    nextButton.setEnabled(false);
                    lastButton.setEnabled(false);
                }
            }
            else
            if (e.getSource() == previousButton )
            {
                if (imageCounter >=1)
                {
                    imageCounter -=1;
                    zoomCounter = 0;
                    nextButton.setEnabled(true);
                    lastButton.setEnabled(true);
                    scaleX = 1;
                    scaleY = 1;
                    currentImage = images[imageCounter].getImageFile();
                    RefreshPic(currentImage);
                }
                else
                {
                    previousButton.setEnabled(false);
                    firstButton.setEnabled(false);
                }
            }
            else
            if (e.getSource() == exitItem)
            {
                System.exit(1);
            }
            else
            if(e.getSource() == playSoundButton || e.getSource() == playSoundItem)
            {
                try
                {
                    images[imageCounter].PlaySound();
                }
                catch (Exception ex)
                {
                    JOptionPane.showMessageDialog(null, "Audio file cannot be loaded.", "Audio File Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            else
            if (e.getSource() == lastButton)
            {

                imageCounter =9;
                zoomCounter = 0;
                nextButton.setEnabled(false);
                lastButton.setEnabled(false);
                previousButton.setEnabled(true);
                firstButton.setEnabled(true);
                scaleX = 1;
                scaleY = 1;
                currentImage = images[imageCounter].getImageFile();
                RefreshPic(currentImage);

            }
            else
            if (e.getSource() == firstButton)
            {

                imageCounter =0;
                zoomCounter = 0;
                nextButton.setEnabled(true);
                lastButton.setEnabled(true);
                previousButton.setEnabled(false);
                firstButton.setEnabled(false);
                scaleX = 1;
                scaleY = 1;
                currentImage = images[imageCounter].getImageFile();
                RefreshPic(currentImage);

            }
            else
            if (e.getSource() == zoomInButton || e.getSource() == zoomInItem)
            {
                if (zoomCounter < 4)
                {
                    zoomCounter++;
                    ZoomImage(true);
                    zoomOutButton.setEnabled(true);
                    zoomOutItem.setEnabled(true);
                }
                else
                {
                    zoomInButton.setEnabled(false);
                    zoomInItem.setEnabled(false);
                }
            }
            else
            if (e.getSource() == zoomOutButton || e.getSource() == zoomOutItem)
            {
                if (zoomCounter > -5)
                {
                    zoomCounter--;
                    ZoomImage(false);
                    zoomInButton.setEnabled(true);
                    zoomInItem.setEnabled(true);
                }
                else
                {
                    zoomOutButton.setEnabled(false);
                    zoomOutItem.setEnabled(false);
                }
            }
            else
            if (e.getSource() == helpItem )
            {
                JOptionPane.showMessageDialog(null, "To close the album, click close. This hides all pictures but the program is still open. To reopen, click open." + System.getProperty("line.separator") +
                        "To zoom in or out on the picture click the proper zoom button or menu option." +  System.getProperty("line.separator") +
                        "Click play sound to hear a sound (if the image has a sound)." +  System.getProperty("line.separator") +
                        "To cycle through the pictures, click the proper arrow. Double arrows mean first or last picture." +  System.getProperty("line.separator")
                        , "Image Album: Help",JOptionPane.INFORMATION_MESSAGE );

                JOptionPane.showMessageDialog(null,"Hot keys are: Alt + O to open, Alt + C to close, Alt + Left (Arrow) for previous picture." +  System.getProperty("line.separator")+
                        "Alt + right for next picture, Alt + Home for first picture, Alt + End for last picture." +  System.getProperty("line.separator") +
                        "Alt + up  for zoom in, Alt + Down for zoom out, Alt + P for play audio." +  System.getProperty("line.separator") +
                        "Alt + F  for file menu, Alt + V for view menu, Alt + M for help menu." +  System.getProperty("line.separator") +
                        "Alt + H  for help, Alt + a for the about section."+  System.getProperty("line.separator") +
                        "You can not use short cut keys for menu items without accessing the containing menu first.", "Image Album: Help",JOptionPane.INFORMATION_MESSAGE );
            }
            else
            if (e.getSource() == aboutItem )
            {
                 JOptionPane.showMessageDialog(null,"Developer: Silne Dorlus" +  System.getProperty("line.separator")+
                "Date: 05/22/2012" +  System.getProperty("line.separator") +
                "Version: 1.0" +  System.getProperty("line.separator") +
                "Difficulty: Moderate" , "Image Album: Help",JOptionPane.INFORMATION_MESSAGE );
            }
        }
    }
    public void RefreshPic(BufferedImage image)
    {
        picLabel.setVisible(false);
        icon =  new ImageIcon(image);
        picLabel.setSize(image.getWidth(), image.getHeight());
        picLabel.setIcon(icon);
        picLabel.setVisible(true);
    }
    public void ZoomImage(boolean zoomIn)
    {
        if (zoomIn == true)
        {
            scaleX += .1;
            scaleY += .1;
        }
        else
        {
            scaleX -= .1;
            scaleY -= .1;
        }
        width = currentImage.getWidth();
        height = currentImage.getHeight();
        resizedImage = new BufferedImage(width ,height, BufferedImage.TYPE_INT_ARGB);
        AffineTransform affineTransform = new AffineTransform();
        affineTransform.scale(scaleX, scaleY);
        AffineTransformOp scaleOperation = new AffineTransformOp(affineTransform, AffineTransformOp.TYPE_BILINEAR);
        resizedImage = scaleOperation.filter(currentImage, resizedImage);
        RefreshPic(resizedImage);
    }
}


