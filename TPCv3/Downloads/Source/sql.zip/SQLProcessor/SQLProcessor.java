import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.*;

/***********************************************************************
 * Developer: Silne Dorlus
 * Date: 6/23/12
 * Purpose: To allow the user to process SQL queries against the supplied
 * contacts database.
 **********************************************************************/
public class SQLProcessor extends JFrame
{
    //Create all GUI elements and class variables.
    ActionListener listener = new SQLActionListener();
    JButton btnExecute = new JButton("Execute");
    JButton btnClear = new JButton("Clear");
    JButton btnHelp = new JButton("Help");
    JButton btnExit = new JButton("Exit");
    JTextArea textStatement = new JTextArea(4 , 50);
    JTextArea textResults = new JTextArea(6,35);
    JScrollPane scrollStatement;
    JScrollPane scrollResults;
    JPanel panelEast = new JPanel();
    JPanel panelWest = new JPanel();
    JPanel panelNorth = new JPanel();
    Connection connect;
    Statement statement = null;
    ResultSet resultSet = null;
    ResultSetMetaData metaData = null;

    public SQLProcessor()
    {
        //Set the layout of the application to BorderLayout and add panels to the JFrame
        setLayout(new BorderLayout());
        add(panelNorth, BorderLayout.NORTH);
        add(panelWest, BorderLayout.WEST);
        add(panelEast, BorderLayout.EAST);

        //Create titled border for panelNorth set the layout to grid layout, set line wrap, add to JScrollPane and add
        //JScrollPane to panelNorth.
        panelNorth.setBorder(BorderFactory.createTitledBorder("Enter SQL Statement"));
        panelNorth.setLayout(new GridLayout());
        textStatement.setLineWrap(true);
        scrollStatement = new JScrollPane(textStatement);
        panelNorth.add(scrollStatement);

        //Create titled border for panelWest set the layout to grid layout, set line wrap and editable
        //add to JScrollPane and add JScrollPane to panelWest.
        panelWest.setBorder(BorderFactory.createTitledBorder("SQL Results"));
        panelWest.setLayout(new GridLayout());
        textResults.setEditable(false);
        textResults.setForeground(Color.blue);
        scrollResults = new JScrollPane(textResults);
        panelWest.add(scrollResults);


        //Add buttons to panelEast and set the border.
        panelEast.setBorder(BorderFactory.createTitledBorder("Commands"));
        panelEast.setLayout(new GridLayout(4,1));
        panelEast.add(btnExecute);
        panelEast.add(btnClear);
        panelEast.add(btnHelp);
        panelEast.add(btnExit);
        
        //Add actionListeners to all buttons
        btnExecute.addActionListener(listener);
        btnClear.addActionListener(listener);
        btnExit.addActionListener(listener);
        btnHelp.addActionListener(listener);

        //Set shortcut keys and mnemonics
        btnClear.setMnemonic(KeyEvent.VK_C);
        btnExecute.setMnemonic(KeyEvent.VK_E);
        btnExit.setMnemonic(KeyEvent.VK_X);
        btnHelp.setMnemonic(KeyEvent.VK_H);
    }
    public static void main (String[] args)
    {
        //Create new instance of class, set title, dimensions, resizable, visibility and default close operation.
        SQLProcessor processor = new SQLProcessor();
        processor.setTitle("SQL Processor");
        processor.setSize(500, 250);
        processor.setResizable(false);
        processor.setVisible(true);
        processor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public class SQLActionListener implements ActionListener
    {
         public void actionPerformed(ActionEvent event)
         {
             //If the execute button is clicked.
             if(event.getSource() == btnExecute)
             {
                textResults.setText(null);
                try
                {
                    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                    connect = DriverManager.getConnection("jdbc:odbc:Contacts");
                    statement = connect.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                            ResultSet.CONCUR_READ_ONLY);

                    String queryString = textStatement.getText().toUpperCase();
                    if (!queryString.isEmpty() )
                    {
                        if (queryString.startsWith("SELECT"))
                        {
                             RunSelectQuery(queryString);
                        }
                        else if (queryString.startsWith("UPDATE") || queryString.startsWith("CREATE")  ||
                                 queryString.startsWith("INSERT")   || queryString.startsWith("DELETE")||
                                queryString.startsWith("DROP"))
                        {
                             RunModifyQuery(queryString);
                        }
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "No query found. Please enter a valid SQL query. ", "Missing Query Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }
                catch (ClassNotFoundException ex)
                {
                    JOptionPane.showMessageDialog(null, "There was an error connecting to the database. Please try again.",
                            "Database Connect Error", JOptionPane.ERROR_MESSAGE);
                }
                catch (SQLException ex)
                {
                    JOptionPane.showMessageDialog(null, "The query entered was not valid. Please enter a valid query.",
                            "Invalid Query Error", JOptionPane.ERROR_MESSAGE);
                }
             }
             else if(event.getSource() == btnClear)
             {
                 textResults.setText(null);
                 textStatement.setText(null);
                 textStatement.requestFocus();
             }
             else if (event.getSource() == btnExit)
             {
                 int decision = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit?",
                         JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                 if (decision == JOptionPane.YES_OPTION)
                 {
                     System.exit(1);
                 }
             }
             else if (event.getSource() == btnHelp)
             {
                 JOptionPane.showMessageDialog(null, "Enter your SQL Statement, one at a time, into the given SQL area." + System.getProperty("line.separator") +
                         "Click the execute button to run the query." +  System.getProperty("line.separator") +
                         "The results will show up in the results area. " +  System.getProperty("line.separator") +
                         "Click the clear button to clear both areas and enter a new statement. "  +   System.getProperty("line.separator") +
                         "Shortcut keys are: Execute: Alt + E, Clear: Alt + C," +  System.getProperty("line.separator") +
                         "Help: Alt + H, Exit: Alt + X" +  System.getProperty("line.separator") ,
                         "SQL Processor: Help",JOptionPane.INFORMATION_MESSAGE );
             }
         }
    }
    public void RunModifyQuery(String updateString)
    {

          try
          {
             int  affectedRows = statement.executeUpdate(updateString);
             if (updateString.startsWith("CREATE"))
             {
                 textResults.setText("CREATE TABLE successful.");
             }
              else if(updateString.startsWith("DROP"))
             {
                 textResults.setText("DROP successful.");
             }
             else
             if (updateString.startsWith("UPDATE")||updateString.startsWith("INSERT") || updateString.startsWith("DELETE"))
             {

                 if( affectedRows > 0)
                 {
                     if (updateString.startsWith("UPDATE"))
                     {
                        textResults.setText( affectedRows + " row(s) updated by query.");
                     }
                     else if (updateString.startsWith("INSERT"))
                     {
                          textResults.setText( affectedRows + " row(s) added by query.");
                     }
                     else if(updateString.startsWith("DELETE"))
                     {
                         textResults.setText(affectedRows + " row(s) deleted by query.");
                     }
                 }
                  else
                 {
                     textResults.setText("No rows updated by query.");
                 }
             }
          }
          catch (SQLException ex)
          {
              JOptionPane.showMessageDialog(null, "There was an error updating the database. Please try again.",
                      "SQL Error", JOptionPane.ERROR_MESSAGE);
          }
    }
    public void RunSelectQuery(String selectString)
    {
        try
        {
            resultSet = statement.executeQuery(selectString);

            metaData = resultSet.getMetaData();

            int numOfColumns = metaData.getColumnCount();
            resultSet.last();
            int numberOfRows = resultSet.getRow();
            if (numberOfRows > 0)
            {
                resultSet.beforeFirst();
                while (resultSet.next())
                {
                    for (int i = 1; i <= numOfColumns ; i++)
                    {
                        if (i < numOfColumns)
                        {
                            textResults.append(resultSet.getObject(i).toString() + "\t");

                        }
                        else
                        {
                            textResults.append(resultSet.getObject(i).toString() + "\t");
                            textResults.append(System.getProperty("line.separator"));
                        }
                    }
                }
            }
           else
           {
              textResults.append("The supplied query returned no results.");
           }
            try
            {
                resultSet.close();
                statement.close();
                connect.close();
            }
            catch (Exception ex)
            {
                JOptionPane.showMessageDialog(null, "Error disconnecting from database", "Disconnect Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
        catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, "The supplied query is invalid.", "SQL Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
